

<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Manage Enquiry')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item"><?php echo e(__('Enquiry')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('action-btn'); ?>
    <div class="float-end">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_add')): ?>
            <a href="<?php echo e(route('enquiry.create')); ?>" data-bs-toggle="tooltip" title="<?php echo e(__('Create')); ?>" class="btn btn-sm btn-primary">
                <i class="ti ti-plus"></i>
            </a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <!-- Top Controls -->
            <div class="row mb-3">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <span class="me-3"><?php echo e(__('Show')); ?></span>
                        <select class="form-select form-select-sm w-auto" id="entries_per_page">
                            <option value="10">10 <?php echo e(__('entries')); ?></option>
                            <option value="25">25 <?php echo e(__('entries')); ?></option>
                            <option value="50">50 <?php echo e(__('entries')); ?></option>
                            <option value="100">100 <?php echo e(__('entries')); ?></option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-secondary btn-sm">
                            <i class="ti ti-printer"></i> <?php echo e(__('Print')); ?>

                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm">
                            <i class="ti ti-file-text"></i> <?php echo e(__('CSV')); ?>

                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="ti ti-columns"></i> <?php echo e(__('Columns')); ?>

                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Enquiry No')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Enquiry Date')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Company Name')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Salesman')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Status')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Enquiry Created Date')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('Issued')); ?></a></li>
                            <li><a class="dropdown-item" href="#"><input type="checkbox" checked> <?php echo e(__('POP')); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Search & Filter Form -->
            <form method="GET" action="<?php echo e(route('enquiry.index')); ?>" class="row mb-3">
                <div class="col-md-3">
                    <label for="from_date" class="form-label"><?php echo e(__('From Date')); ?></label>
                    <input type="date" class="form-control" id="from_date" name="from_date" value="<?php echo e(request('from_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="to_date" class="form-label"><?php echo e(__('To Date')); ?></label>
                    <input type="date" class="form-control" id="to_date" name="to_date" value="<?php echo e(request('to_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="company_id" class="form-label"><?php echo e(__('Company')); ?></label>
                    <select class="form-control select2" id="company_id" name="company_id">
                        <option value=""><?php echo e(__('All Companies')); ?></option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request('company_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="salesman_id" class="form-label"><?php echo e(__('Salesman')); ?></label>
                    <select class="form-control select2" id="salesman_id" name="salesman_id">
                        <option value=""><?php echo e(__('All Salesmen')); ?></option>
                        <?php $__currentLoopData = $salesmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request('salesman_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6 mt-3">
                    <label for="search" class="form-label"><?php echo e(__('Search')); ?></label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="search" name="search" placeholder="<?php echo e(__('Search by Enquiry No, Company Name, etc.')); ?>" value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="ti ti-search"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-6 mt-3 text-end">
                    <label class="form-label d-block">&nbsp;</label>
                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary me-2"><?php echo e(__('Filter')); ?></button>
                        <a href="<?php echo e(route('enquiry.index')); ?>" class="btn btn-secondary"><?php echo e(__('Reset')); ?></a>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th><?php echo e(__('Enquiry No')); ?></th>
                            <th><?php echo e(__('Enquiry Date')); ?></th>
                            <th><?php echo e(__('Company Name')); ?></th>
                            <th><?php echo e(__('Salesman')); ?></th>
                            <th><?php echo e(__('Status')); ?></th>
                            <th><?php echo e(__('Enquiry Created Date')); ?></th>
                            <th><?php echo e(__('Issued')); ?></th>
                            <th><?php echo e(__('POP')); ?></th>
                            <th><?php echo e(__('Purchase Date & Time')); ?></th>
                            <th><?php echo e(__('Quotation Date & Time')); ?></th>
                            <th><?php echo e(__('Action')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <strong><?php echo e($enquiry->serial_no); ?></strong>
                            </td>
                            <td><?php echo e(\Auth::user()->dateFormat($enquiry->enquiry_date, 'd-m-Y')); ?></td>
                            <td>
                                <strong><?php echo e($enquiry->company_name); ?></strong>
                                <?php if($enquiry->kind_attn): ?>
                                    <br><small class="text-muted"><?php echo e(__('Attn:')); ?> <?php echo e($enquiry->kind_attn); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($enquiry->salesman): ?>
                                    <?php echo e($enquiry->salesman->name); ?>

                                    <?php if($enquiry->salesman->phone): ?>
                                        <br><small class="text-muted"><?php echo e($enquiry->salesman->phone); ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e(__('N/A')); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge 
                                    <?php if($enquiry->status == 'completed'): ?> bg-success
                                    <?php elseif($enquiry->status == 'ignored'): ?> bg-danger
                                    <?php elseif($enquiry->status == 'pending'): ?> bg-warning
                                    <?php elseif($enquiry->status == 'assigned'): ?> bg-info
                                    <?php elseif($enquiry->status == 'quoted'): ?> bg-primary
                                    <?php elseif($enquiry->status == 'purchased'): ?> bg-dark
                                    <?php else: ?> bg-secondary <?php endif; ?> p-2 px-3 rounded">
                                    <?php if($enquiry->status == 'completed'): ?>
                                        <?php echo e(__('Completed')); ?>

                                        <?php if($enquiry->quotation_no): ?>
                                            <br><small><?php echo e(__('Question No:')); ?> <?php echo e($enquiry->quotation_no); ?></small>
                                        <?php endif; ?>
                                    <?php elseif($enquiry->status == 'ignored'): ?>
                                        <?php echo e(__('Ignored')); ?>

                                    <?php else: ?>
                                        <?php echo e(ucfirst($enquiry->status)); ?>

                                    <?php endif; ?>
                                </span>
                            </td>
                            <td><?php echo e(\Auth::user()->dateFormat($enquiry->created_at, 'd-m-Y H:i:s')); ?></td>
                            <td>
                                <?php if($enquiry->issued_date): ?>
                                    <?php echo e(\Auth::user()->dateFormat($enquiry->issued_date, 'd-m-Y H:i:s')); ?>

                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($enquiry->pop_date): ?>
                                    <?php echo e(\Auth::user()->dateFormat($enquiry->pop_date, 'd-m-Y H:i:s')); ?>

                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($enquiry->purchase_date_time): ?>
                                    <?php echo e(\Auth::user()->dateFormat($enquiry->purchase_date_time, 'd-m-Y H:i:s')); ?>

                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($enquiry->quotation_date_time): ?>
                                    <?php echo e(\Auth::user()->dateFormat($enquiry->quotation_date_time, 'd-m-Y H:i:s')); ?>

                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        <?php echo e(__('Action')); ?>

                                    </button>
                                    <ul class="dropdown-menu">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_view')): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('enquiry.show', $enquiry->id)); ?>">
                                                    <i class="ti ti-eye me-2"></i> <?php echo e(__('View')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_edit')): ?>
                                            <li>
                                                <a class="dropdown-item" href="<?php echo e(route('enquiry.edit', $enquiry->id)); ?>">
                                                    <i class="ti ti-edit me-2"></i> <?php echo e(__('Edit')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if($enquiry->status == 'pending' || $enquiry->status == 'ignored'): ?>
                                            <li>
                                                <a class="dropdown-item assign-btn" href="#" data-id="<?php echo e($enquiry->id); ?>">
                                                    <i class="ti ti-user-check me-2"></i> <?php echo e(__('Assign')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('enquiry_delete')): ?>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item text-danger delete-btn" href="#" data-id="<?php echo e($enquiry->id); ?>">
                                                    <i class="ti ti-trash me-2"></i> <?php echo e(__('Delete')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <!-- Pagination -->
                <?php if($enquiries->hasPages()): ?>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        <?php echo e(__('Showing')); ?> <?php echo e($enquiries->firstItem()); ?> <?php echo e(__('to')); ?> <?php echo e($enquiries->lastItem()); ?> <?php echo e(__('of')); ?> <?php echo e($enquiries->total()); ?> <?php echo e(__('entries')); ?>

                    </div>
                    <div>
                        <?php echo e($enquiries->links()); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Assign Modal -->
    <div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('Assign Enquiry')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="assignForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="assign_salesman_id" class="form-label"><?php echo e(__('Select Salesman')); ?></label>
                            <select class="form-control select2" id="assign_salesman_id" name="salesman_id" required>
                                <option value=""><?php echo e(__('Select Salesman')); ?></option>
                                <?php $__currentLoopData = $salesmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group mt-3">
                            <label for="assign_date" class="form-label"><?php echo e(__('Assign Date & Time')); ?></label>
                            <input type="datetime-local" class="form-control" id="assign_date" name="assigned_date_time" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Assign')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
<style>
    .table th {
        font-weight: 600;
        background-color: #f8f9fa;
    }
    .badge {
        font-size: 0.85em;
        white-space: normal;
        text-align: left;
    }
    .dropdown-toggle::after {
        margin-left: 0.5em;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.04);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        // Initialize Select2 dropdowns
        $('.select2').select2({
            width: '100%',
            placeholder: "Select an option",
            allowClear: true
        });

        // Set current date time for assign modal
        $('#assign_date').val(moment().format('YYYY-MM-DDTHH:mm'));

        // Assign button click
        $('.assign-btn').click(function(e) {
            e.preventDefault();
            const enquiryId = $(this).data('id');
            $('#assignForm').attr('action', `/enquiry/${enquiryId}/assign`);
            $('#assignModal').modal('show');
        });

        // Delete confirmation
        $('.delete-btn').click(function(e) {
            e.preventDefault();
            const enquiryId = $(this).data('id');
            
            if (confirm('<?php echo e(__("Are You Sure?")); ?>\n\n<?php echo e(__("This action can not be undone. Do you want to continue?")); ?>')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = `/enquiry/${enquiryId}`;
                
                const csrfToken = document.createElement('input');
                csrfToken.type = 'hidden';
                csrfToken.name = '_token';
                csrfToken.value = '<?php echo e(csrf_token()); ?>';
                
                const methodField = document.createElement('input');
                methodField.type = 'hidden';
                methodField.name = '_method';
                methodField.value = 'DELETE';
                
                form.appendChild(csrfToken);
                form.appendChild(methodField);
                document.body.appendChild(form);
                form.submit();
            }
        });

        // Entries per page change
        $('#entries_per_page').change(function() {
            const url = new URL(window.location.href);
            url.searchParams.set('per_page', $(this).val());
            window.location.href = url.toString();
        });

        // Set current value for entries per page
        const urlParams = new URLSearchParams(window.location.search);
        const perPage = urlParams.get('per_page') || '10';
        $('#entries_per_page').val(perPage);

        // Print button
        $('.btn-outline-secondary').on('click', function(e) {
            if ($(this).text().includes('Print')) {
                window.print();
            } else if ($(this).text().includes('CSV')) {
                // Export to CSV functionality
                window.location.href = '<?php echo e(route("enquiry.index")); ?>?export=csv';
            }
        });

        // Column visibility toggle
        $('.dropdown-menu input[type="checkbox"]').change(function() {
            const columnIndex = $(this).closest('.dropdown-item').index();
            const table = $('.datatable').DataTable();
            const column = table.column(columnIndex);
            column.visible(!column.visible());
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Projects\savantec-erp\resources\views/enquiry/index.blade.php ENDPATH**/ ?>