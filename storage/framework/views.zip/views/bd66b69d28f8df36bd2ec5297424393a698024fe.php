

<?php $__env->startSection('page-title'); ?>
    <?php echo e(__('Create Enquiry')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('enquiry.index')); ?>"><?php echo e(__('Enquiry')); ?></a></li>
    <li class="breadcrumb-item"><?php echo e(__('Create')); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(__('Create Enquiry')); ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('enquiry.store')); ?>" enctype="multipart/form-data" id="enquiryForm">
                        <?php echo csrf_field(); ?>
                        
                        <!-- Enquiry Header Section -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="enquiry_no" class="form-label"><?php echo e(__('Enquiry No')); ?></label>
                                    <input type="text" class="form-control bg-light" id="enquiry_no" value="<?php echo e($serialNumber); ?>" readonly>
                                    <input type="hidden" name="serial_no" value="<?php echo e($serialNumber); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="enquiry_date" class="form-label"><?php echo e(__('Date')); ?> <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control" id="enquiry_date" name="enquiry_date" value="<?php echo e(old('enquiry_date', date('Y-m-d'))); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="company_id" class="form-label"><?php echo e(__('Company Name')); ?> <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="company_id" name="company_id" required>
                                        <option value=""><?php echo e(__('Select Company')); ?></option>
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e(old('company_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Company Details Section -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h6 class="border-bottom pb-2"><?php echo e(__('Company Details')); ?></h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kind_attn" class="form-label"><?php echo e(__('Kind Attn.')); ?></label>
                                    <input type="text" class="form-control" id="kind_attn" name="kind_attn" value="<?php echo e(old('kind_attn')); ?>" placeholder="<?php echo e(__('Attention Person Name')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="mail_id" class="form-label"><?php echo e(__('Mail-ID')); ?></label>
                                    <input type="email" class="form-control" id="mail_id" name="mail_id" value="<?php echo e(old('mail_id')); ?>" placeholder="<?php echo e(__('Email Address')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone_no" class="form-label"><?php echo e(__('Phone No')); ?></label>
                                    <input type="text" class="form-control" id="phone_no" name="phone_no" value="<?php echo e(old('phone_no')); ?>" placeholder="<?php echo e(__('Phone Number')); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="remarks" class="form-label"><?php echo e(__('Remarks')); ?></label>
                                    <textarea class="form-control" id="remarks" name="remarks" rows="2" placeholder="<?php echo e(__('Additional Remarks')); ?>"><?php echo e(old('remarks')); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Items Section -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h6 class="border-bottom pb-2"><?php echo e(__('Items')); ?></h6>
                            </div>
                        </div>

                        <!-- Items Container -->
                        <div id="items-container">
                            <div class="item-row mb-4 border p-3 rounded">
                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <h6 class="text-primary"><?php echo e(__('Item 1')); ?></h6>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="item_description_1" class="form-label"><?php echo e(__('Item Description')); ?></label>
                                            <textarea class="form-control" id="item_description_1" name="items[1][description]" rows="3" placeholder="<?php echo e(__('Enter item description, specifications, etc.')); ?>"><?php echo e(old('items.1.description')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="item_qty_1" class="form-label"><?php echo e(__('Quantity')); ?></label>
                                            <input type="number" class="form-control" id="item_qty_1" name="items[1][quantity]" value="<?php echo e(old('items.1.quantity', 1)); ?>" min="1" placeholder="<?php echo e(__('Qty')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="item_unit_1" class="form-label"><?php echo e(__('Unit')); ?></label>
                                            <select class="form-control select2" id="item_unit_1" name="items[1][unit]">
                                                <option value=""><?php echo e(__('Select Unit')); ?></option>
                                                <option value="PCS"><?php echo e(__('PCS')); ?></option>
                                                <option value="SET"><?php echo e(__('SET')); ?></option>
                                                <option value="KG"><?php echo e(__('KG')); ?></option>
                                                <option value="MTR"><?php echo e(__('MTR')); ?></option>
                                                <option value="LTR"><?php echo e(__('LTR')); ?></option>
                                                <option value="BOX"><?php echo e(__('BOX')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="item_remarks_1" class="form-label"><?php echo e(__('Item Remarks')); ?></label>
                                            <textarea class="form-control" id="item_remarks_1" name="items[1][remarks]" rows="2" placeholder="<?php echo e(__('Item specific remarks')); ?>"><?php echo e(old('items.1.remarks')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="item_image_1" class="form-label"><?php echo e(__('Image')); ?></label>
                                            <div class="input-group">
                                                <input type="file" class="form-control" id="item_image_1" name="items[1][image]" accept="image/*">
                                                <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('item_image_1').click()">
                                                    <i class="ti ti-upload"></i> <?php echo e(__('Pick Image')); ?>

                                                </button>
                                            </div>
                                            <small class="text-muted"><?php echo e(__('Upload item image if available')); ?></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Add More Items Button -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <button type="button" id="add-item-btn" class="btn btn-outline-primary">
                                    <i class="ti ti-plus"></i> <?php echo e(__('Add Another Item')); ?>

                                </button>
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Sales & Status Section -->
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h6 class="border-bottom pb-2"><?php echo e(__('Sales & Status')); ?></h6>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="salesman_id" class="form-label"><?php echo e(__('Salesman')); ?> <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="salesman_id" name="salesman_id" required>
                                        <option value=""><?php echo e(__('Select Salesman')); ?></option>
                                        <?php $__currentLoopData = $salesmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($id); ?>" <?php echo e(old('salesman_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status" class="form-label"><?php echo e(__('Status')); ?> <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="status" name="status" required>
                                        <option value=""><?php echo e(__('Select Status')); ?></option>
                                        <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : 'selected'); ?>><?php echo e(__('Pending')); ?></option>
                                        <option value="assigned" <?php echo e(old('status') == 'assigned' ? 'selected' : ''); ?>><?php echo e(__('Assigned')); ?></option>
                                        <option value="quoted" <?php echo e(old('status') == 'quoted' ? 'selected' : ''); ?>><?php echo e(__('Quoted')); ?></option>
                                        <option value="purchased" <?php echo e(old('status') == 'purchased' ? 'selected' : ''); ?>><?php echo e(__('Purchased')); ?></option>
                                        <option value="cancelled" <?php echo e(old('status') == 'cancelled' ? 'selected' : ''); ?>><?php echo e(__('Cancelled')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Date & Time Section -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="assigned_date_time" class="form-label"><?php echo e(__('Assigned Date & Time')); ?></label>
                                    <input type="datetime-local" class="form-control" id="assigned_date_time" name="assigned_date_time" value="<?php echo e(old('assigned_date_time')); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="quotation_date_time" class="form-label"><?php echo e(__('Quotation Date & Time')); ?></label>
                                    <input type="datetime-local" class="form-control" id="quotation_date_time" name="quotation_date_time" value="<?php echo e(old('quotation_date_time')); ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="purchase_date_time" class="form-label"><?php echo e(__('Purchase Date & Time')); ?></label>
                                    <input type="datetime-local" class="form-control" id="purchase_date_time" name="purchase_date_time" value="<?php echo e(old('purchase_date_time')); ?>">
                                </div>
                            </div>
                        </div>

                        <!-- Buttons -->
                        <div class="form-group text-end mt-4">
                            <button type="submit" class="btn btn-primary">
                                <i class="ti ti-check"></i> <?php echo e(__('Save Enquiry')); ?>

                            </button>
                            <a href="<?php echo e(route('enquiry.index')); ?>" class="btn btn-secondary">
                                <i class="ti ti-x"></i> <?php echo e(__('Cancel')); ?>

                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
<style>
    .select2-container .select2-selection--single {
        height: 38px;
        border: 1px solid #ced4da;
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered {
        line-height: 36px;
        color: #495057;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 36px;
    }
    .item-row {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6 !important;
    }
    .item-row h6 {
        font-weight: 600;
    }
    .bg-light {
        background-color: #f8f9fa !important;
        cursor: not-allowed;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        // Initialize Select2 dropdowns
        $('.select2').select2({
            width: '100%',
            placeholder: "Select an option",
            allowClear: true
        });

        // Set today's date as default for enquiry date
        $('#enquiry_date').val(new Date().toISOString().split('T')[0]);

        // Add item functionality
        let itemCount = 1;
        $('#add-item-btn').click(function() {
            itemCount++;
            
            const newItem = `
                <div class="item-row mb-4 border p-3 rounded">
                    <div class="row mb-3">
                        <div class="col-md-10">
                            <h6 class="text-primary"><?php echo e(__('Item')); ?> ${itemCount}</h6>
                        </div>
                        <div class="col-md-2 text-end">
                            <button type="button" class="btn btn-sm btn-danger remove-item-btn">
                                <i class="ti ti-trash"></i> <?php echo e(__('Remove')); ?>

                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="item_description_${itemCount}" class="form-label"><?php echo e(__('Item Description')); ?></label>
                                <textarea class="form-control" id="item_description_${itemCount}" name="items[${itemCount}][description]" rows="3" placeholder="<?php echo e(__('Enter item description, specifications, etc.')); ?>"></textarea>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="item_qty_${itemCount}" class="form-label"><?php echo e(__('Quantity')); ?></label>
                                <input type="number" class="form-control" id="item_qty_${itemCount}" name="items[${itemCount}][quantity]" value="1" min="1" placeholder="<?php echo e(__('Qty')); ?>">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="item_unit_${itemCount}" class="form-label"><?php echo e(__('Unit')); ?></label>
                                <select class="form-control select2" id="item_unit_${itemCount}" name="items[${itemCount}][unit]">
                                    <option value=""><?php echo e(__('Select Unit')); ?></option>
                                    <option value="PCS"><?php echo e(__('PCS')); ?></option>
                                    <option value="SET"><?php echo e(__('SET')); ?></option>
                                    <option value="KG"><?php echo e(__('KG')); ?></option>
                                    <option value="MTR"><?php echo e(__('MTR')); ?></option>
                                    <option value="LTR"><?php echo e(__('LTR')); ?></option>
                                    <option value="BOX"><?php echo e(__('BOX')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="item_remarks_${itemCount}" class="form-label"><?php echo e(__('Item Remarks')); ?></label>
                                <textarea class="form-control" id="item_remarks_${itemCount}" name="items[${itemCount}][remarks]" rows="2" placeholder="<?php echo e(__('Item specific remarks')); ?>"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="item_image_${itemCount}" class="form-label"><?php echo e(__('Image')); ?></label>
                                <div class="input-group">
                                    <input type="file" class="form-control" id="item_image_${itemCount}" name="items[${itemCount}][image]" accept="image/*">
                                    <button type="button" class="btn btn-outline-secondary" onclick="document.getElementById('item_image_${itemCount}').click()">
                                        <i class="ti ti-upload"></i> <?php echo e(__('Pick Image')); ?>

                                    </button>
                                </div>
                                <small class="text-muted"><?php echo e(__('Upload item image if available')); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            $('#items-container').append(newItem);
            
            // Initialize Select2 for new dropdowns
            $(`#item_unit_${itemCount}`).select2({
                width: '100%',
                placeholder: "Select an option",
                allowClear: true
            });
        });

        // Remove item functionality
        $(document).on('click', '.remove-item-btn', function() {
            if (itemCount > 1) {
                $(this).closest('.item-row').remove();
                itemCount--;
                
                // Renumber remaining items
                $('.item-row').each(function(index) {
                    const newNumber = index + 1;
                    $(this).find('h6').text(`Item ${newNumber}`);
                    
                    // Update all input names
                    $(this).find('[name*="description"]').attr('name', `items[${newNumber}][description]`);
                    $(this).find('[name*="quantity"]').attr('name', `items[${newNumber}][quantity]`);
                    $(this).find('[name*="unit"]').attr('name', `items[${newNumber}][unit]`);
                    $(this).find('[name*="remarks"]').attr('name', `items[${newNumber}][remarks]`);
                    $(this).find('[name*="image"]').attr('name', `items[${newNumber}][image]`);
                });
            }
        });

        // Form validation
        $('#enquiryForm').submit(function(e) {
            const hasItems = $('#items-container .item-row').length > 0;
            if (!hasItems) {
                e.preventDefault();
                alert('Please add at least one item.');
                return false;
            }
            
            // Check if at least one item has description
            let hasDescription = false;
            $('#items-container textarea[name*="description"]').each(function() {
                if ($(this).val().trim() !== '') {
                    hasDescription = true;
                }
            });
            
            if (!hasDescription) {
                e.preventDefault();
                alert('Please add description for at least one item.');
                return false;
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ADMIN\Projects\savantec-erp\resources\views/enquiry/create.blade.php ENDPATH**/ ?>